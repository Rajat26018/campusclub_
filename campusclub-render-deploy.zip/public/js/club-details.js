// ============================================================================
// club-details.js - Interactive Single Club Profile View
// ============================================================================
// Detailed view for a single club: faculty coordinator, description,
// member leadership roster with avatars, and organized events with calendar blocks.
// ============================================================================

let currentClubId = null;
let currentClubData = null;

async function loadClubDetails() {
  const urlParams = new URLSearchParams(window.location.search);
  currentClubId = urlParams.get('id');

  if (!currentClubId) {
    document.getElementById('clubDetailContainer').innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">⚠️</div>
        <div class="empty-title">Club ID Missing</div>
        <p>No club ID was specified in the URL.</p>
        <a href="clubs.html" class="btn btn-primary" style="margin-top: 1rem;">Back to Clubs</a>
      </div>
    `;
    return;
  }

  try {
    const res = await fetch(`/api/clubs/${currentClubId}`);
    const result = await res.json();

    if (!result.success || !result.data) {
      throw new Error(result.message || 'Club not found');
    }

    currentClubData = result.data;
    renderClubDetails(currentClubData);
  } catch (err) {
    console.error('Error loading club details:', err);
    document.getElementById('clubDetailContainer').innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">❌</div>
        <div class="empty-title">Error Loading Club</div>
        <p>${escapeHTML(err.message)}</p>
        <a href="clubs.html" class="btn btn-primary" style="margin-top: 1rem;">Back to Clubs</a>
      </div>
    `;
  }
}

function renderClubDetails(club) {
  document.title = `${club.club_name} - Campusclub`;

  const container = document.getElementById('clubDetailContainer');
  if (!container) return;

  const members = club.members || [];
  const events = club.events || [];

  container.innerHTML = `
    <!-- Top Action Navigation -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem;">
      <a href="clubs.html" class="btn btn-secondary btn-sm">← Back to All Clubs</a>
      <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
        <button onclick="shareCurrentClub()" class="btn btn-secondary btn-sm">🔗 Share Club</button>
        <a href="edit-club.html?id=${club.club_id}" class="btn btn-secondary btn-sm">✏️ Edit Club</a>
        <button onclick="handleDeleteCurrentClub()" class="btn btn-outline-danger btn-sm">🗑️ Delete Club</button>
      </div>
    </div>

    <!-- Club Header Banner -->
    <div class="detail-banner">
      <div class="detail-header">
        <div style="display: flex; align-items: center; gap: 1.25rem;">
          ${getClubLogoHTML(club, 'lg')}
          <div>
            <div style="margin-bottom: 0.4rem;">${getCategoryBadge(club.category)}</div>
            <h1 class="detail-title">${escapeHTML(club.club_name)}</h1>
          </div>
        </div>
        <div style="display: flex; gap: 0.65rem; flex-wrap: wrap;">
          <a href="join-club.html?club_id=${club.club_id}" class="btn btn-primary">➕ Join This Club</a>
          <a href="add-event.html?club_id=${club.club_id}" class="btn btn-secondary">🎉 Schedule Event</a>
        </div>
      </div>

      <p style="font-size: 1.05rem; color: var(--text-muted); line-height: 1.65; margin-top: 1.25rem; max-width: 900px;">
        ${escapeHTML(cleanClubDescription(club.description) || 'No description provided for this club.')}
      </p>

      <div class="detail-stats">
        <div class="detail-stat">
          <span>👤 Faculty Coordinator:</span>
          <strong>${escapeHTML(club.faculty_coordinator || 'Not Assigned')}</strong>
        </div>
        <div class="detail-stat">
          <span>📅 Established:</span>
          <strong>${escapeHTML(club.founded_year || 'N/A')}</strong>
        </div>
        <div class="detail-stat">
          <span>👥 Total Enrolled:</span>
          <strong>${members.length} Member(s)</strong>
        </div>
        <div class="detail-stat">
          <span>🎉 Events Organized:</span>
          <strong>${events.length} Event(s)</strong>
        </div>
      </div>
    </div>

    <!-- Tabs: Members vs Events -->
    <div class="tabs-header">
      <button class="tab-btn active" id="tabMembersBtn" onclick="switchTab('members')">
        👥 Members & Leadership (${members.length})
      </button>
      <button class="tab-btn" id="tabEventsBtn" onclick="switchTab('events')">
        🎉 Club Events (${events.length})
      </button>
    </div>

    <!-- Tab 1: Members Content -->
    <div id="tabMembersContent">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 0.5rem;">
        <h3 style="font-size: 1.3rem; font-weight: 700;">Club Roster</h3>
        <a href="join-club.html?club_id=${club.club_id}" class="btn btn-primary btn-sm">+ Enroll Student in Club</a>
      </div>
      ${renderMembersTable(members)}
    </div>

    <!-- Tab 2: Events Content -->
    <div id="tabEventsContent" style="display: none;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 0.5rem;">
        <h3 style="font-size: 1.3rem; font-weight: 700;">Events Organized by ${escapeHTML(club.club_name)}</h3>
        <a href="add-event.html?club_id=${club.club_id}" class="btn btn-primary btn-sm">+ Add New Event</a>
      </div>
      ${renderEventsList(events)}
    </div>
  `;
}

function renderMembersTable(members) {
  if (members.length === 0) {
    return `
      <div class="empty-state">
        <div class="empty-icon">👥</div>
        <div class="empty-title">No Enrolled Members Yet</div>
        <p>This club does not have any student members registered yet.</p>
        <a href="join-club.html?club_id=${currentClubId}" class="btn btn-primary btn-sm" style="margin-top: 1rem;">+ Join Club</a>
      </div>
    `;
  }

  return `
    <div class="table-container">
      <table class="custom-table">
        <thead>
          <tr>
            <th>USN</th>
            <th>Member Profile</th>
            <th>Branch / Semester</th>
            <th>Role</th>
            <th>Joined On</th>
            <th>Contact</th>
          </tr>
        </thead>
        <tbody>
          ${members.map(m => {
            const isLead = /president|lead|head|secretary|coordinator/i.test(m.role || '');
            const roleBadgeClass = isLead ? 'badge-role-lead' : 'badge-role';
            const avatar = getAvatarHTML(m.full_name);

            return `
              <tr>
                <td><strong>${escapeHTML(m.usn)}</strong></td>
                <td>
                  <div class="member-cell">
                    ${avatar}
                    <div style="font-weight: 700;">${escapeHTML(m.full_name)}</div>
                  </div>
                </td>
                <td>${escapeHTML(m.course)} (Sem ${escapeHTML(m.semester)})</td>
                <td>
                  <span class="badge ${roleBadgeClass}">
                    ${isLead ? '⭐' : '🔹'} ${escapeHTML(m.role || 'Member')}
                  </span>
                </td>
                <td>${formatDate(m.joined_on)}</td>
                <td>
                  <a href="mailto:${escapeHTML(m.email)}" class="btn btn-secondary btn-sm" style="font-size: 0.8rem;">
                    ✉️ Email
                  </a>
                </td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function renderEventsList(events) {
  if (events.length === 0) {
    return `
      <div class="empty-state">
        <div class="empty-icon">🎉</div>
        <div class="empty-title">No Events Scheduled</div>
        <p>This club has not posted any campus events yet.</p>
        <a href="add-event.html?club_id=${currentClubId}" class="btn btn-primary btn-sm" style="margin-top: 1rem;">+ Schedule First Event</a>
      </div>
    `;
  }

  return `
    <div class="cards-grid">
      ${events.map(ev => {
        const dateParts = getEventDateParts(ev.event_date);
        const countdown = getEventCountdownPill(ev.event_date);

        return `
          <div class="card event-card">
            <div class="card-header">
              <div class="event-ticket-top">
                <div class="calendar-box">
                  <div class="calendar-month">${dateParts.month}</div>
                  <div class="calendar-day">${dateParts.day}</div>
                </div>
                <div>
                  <h4 class="card-title">${escapeHTML(ev.title)}</h4>
                  <div style="margin-top: 0.35rem;">${countdown}</div>
                </div>
              </div>
            </div>
            <div class="card-body">
              <p class="card-desc">${escapeHTML(ev.description || 'No description provided.')}</p>
              <div class="card-meta">
                <div class="meta-item">
                  <span>📅 Date:</span>
                  <strong>${formatDateTime(ev.event_date)}</strong>
                </div>
                <div class="meta-item">
                  <span>📍 Venue:</span>
                  <strong>${escapeHTML(ev.venue || 'Campus Auditorium')}</strong>
                </div>
                <div class="meta-item">
                  <span>🎟️ Attendees:</span>
                  <strong>${ev.attendees_count || 0} registered</strong>
                </div>
              </div>
            </div>
            <div class="card-footer">
              <a href="events.html" class="btn btn-primary btn-sm">View on Events Page</a>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function switchTab(tabName) {
  const membersTab = document.getElementById('tabMembersContent');
  const eventsTab = document.getElementById('tabEventsContent');
  const membersBtn = document.getElementById('tabMembersBtn');
  const eventsBtn = document.getElementById('tabEventsBtn');

  if (tabName === 'members') {
    membersTab.style.display = 'block';
    eventsTab.style.display = 'none';
    membersBtn.classList.add('active');
    eventsBtn.classList.remove('active');
  } else {
    membersTab.style.display = 'none';
    eventsTab.style.display = 'block';
    eventsBtn.classList.add('active');
    membersBtn.classList.remove('active');
  }
}

function shareCurrentClub() {
  if (!currentClubData) return;
  copyToClipboard(window.location.href, `Link to ${currentClubData.club_name} copied!`);
}

async function handleDeleteCurrentClub() {
  if (!currentClubData) return;
  const confirmed = confirm(`Are you sure you want to delete "${currentClubData.club_name}"?\n\nThis will remove the club, its memberships, and its events. This action cannot be undone.`);
  if (!confirmed) return;

  try {
    const res = await fetch(`/api/clubs/${currentClubId}`, { method: 'DELETE' });
    const result = await res.json();
    if (!result.success) throw new Error(result.message);

    alert(`Club "${currentClubData.club_name}" was deleted successfully.`);
    window.location.href = 'clubs.html';
  } catch (err) {
    alert('Error deleting club: ' + err.message);
  }
}

document.addEventListener('DOMContentLoaded', loadClubDetails);
