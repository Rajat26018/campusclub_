// ============================================================================
// members.js - Interactive Students & Members Directory
// ============================================================================
// Includes student initials avatars, one-click USN copying, live search,
// semester filtering, and direct club assignment shortcuts.
// ============================================================================

let allMembers = [];

async function loadMembers() {
  const container = document.getElementById('membersTableBody');
  if (!container) return;

  container.innerHTML = `<tr><td colspan="6" style="text-align: center;"><div class="spinner"></div></td></tr>`;

  try {
    const res = await fetch('/api/members');
    const result = await res.json();

    if (!result.success) throw new Error(result.message || 'Failed to load members');

    allMembers = result.data;
    filterMembers();
  } catch (err) {
    console.error('Error loading members:', err);
    container.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; color: var(--danger); padding: 2rem;">
          Failed to load members: ${escapeHTML(err.message)}
        </td>
      </tr>
    `;
  }
}

function renderMembers(members) {
  const tbody = document.getElementById('membersTableBody');
  const countBadge = document.getElementById('memberCountBadge');
  if (!tbody) return;

  if (countBadge) {
    countBadge.textContent = `${members.length} of ${allMembers.length} enrolled`;
  }

  if (members.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; padding: 3.5rem 1.5rem;">
          <div class="empty-state" style="border: none; padding: 0;">
            <div class="empty-icon">👥</div>
            <div class="empty-title">No Students Found</div>
            <p>No members match the current search or filter.</p>
            <a href="add-member.html" class="btn btn-primary btn-sm" style="margin-top: 1rem;">+ Register Student</a>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = members.map(m => {
    let clubsDisplay = '<span style="color: var(--text-light); font-style: italic; font-size: 0.85rem;">No clubs yet</span>';
    if (m.club_names) {
      const clubsList = m.club_names.split(', ');
      clubsDisplay = clubsList.map(c => `
        <span class="badge badge-tech" style="margin: 2px 2px 2px 0;">${escapeHTML(c)}</span>
      `).join('');
    }

    const avatar = getAvatarHTML(m.full_name);

    return `
      <tr>
        <td>
          <div style="display: flex; align-items: center; gap: 0.4rem;">
            <code style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-weight: 700; color: var(--dark);">${escapeHTML(m.usn)}</code>
            <button onclick="copyToClipboard('${escapeHTML(m.usn)}', 'USN copied!')" style="background:none; border:none; cursor:pointer; opacity: 0.6;" title="Copy USN">📋</button>
          </div>
        </td>
        <td>
          <div class="member-cell">
            ${avatar}
            <div>
              <div style="font-weight: 700; color: var(--dark);">${escapeHTML(m.full_name)}</div>
              <div style="font-size: 0.8rem; color: var(--text-muted); display: flex; align-items: center; gap: 0.5rem; margin-top: 2px;">
                <a href="mailto:${escapeHTML(m.email)}" style="color: var(--text-muted);">✉️ ${escapeHTML(m.email)}</a>
                ${m.phone ? `<span style="color: var(--text-light);">•</span> <a href="tel:${escapeHTML(m.phone)}" style="color: var(--text-muted);">📞 ${escapeHTML(m.phone)}</a>` : ''}
              </div>
            </div>
          </div>
        </td>
        <td>
          <div style="font-weight: 600;">${escapeHTML(m.course)}</div>
        </td>
        <td>
          <span class="badge badge-other">Sem ${escapeHTML(m.semester)}</span>
        </td>
        <td style="max-width: 250px;">
          ${clubsDisplay}
        </td>
        <td>
          <a href="join-club.html?member_id=${m.member_id}" class="btn btn-secondary btn-sm" title="Enroll in a Club">
            ➕ Join Club
          </a>
        </td>
      </tr>
    `;
  }).join('');
}

function filterMembers() {
  const searchInput = document.getElementById('memberSearchInput');
  const semesterFilter = document.getElementById('semesterFilter');
  const clearBtn = document.getElementById('memberSearchClear');

  const term = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const sem = semesterFilter ? semesterFilter.value : '';

  if (clearBtn) {
    clearBtn.style.display = term ? 'block' : 'none';
  }

  const filtered = allMembers.filter(m => {
    const matchesSearch = 
      (m.full_name && m.full_name.toLowerCase().includes(term)) ||
      (m.usn && m.usn.toLowerCase().includes(term)) ||
      (m.email && m.email.toLowerCase().includes(term)) ||
      (m.course && m.course.toLowerCase().includes(term)) ||
      (m.club_names && m.club_names.toLowerCase().includes(term));

    const matchesSem = !sem || String(m.semester) === sem;

    return matchesSearch && matchesSem;
  });

  renderMembers(filtered);
}

document.addEventListener('DOMContentLoaded', () => {
  loadMembers();

  const searchInput = document.getElementById('memberSearchInput');
  if (searchInput) searchInput.addEventListener('input', filterMembers);

  const semesterFilter = document.getElementById('semesterFilter');
  if (semesterFilter) semesterFilter.addEventListener('change', filterMembers);

  const clearBtn = document.getElementById('memberSearchClear');
  if (clearBtn) clearBtn.addEventListener('click', () => {
    if (searchInput) {
      searchInput.value = '';
      filterMembers();
    }
  });
});
