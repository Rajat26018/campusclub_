// ============================================================================
// events.js - Interactive Campus Events & 1-Click Registration
// ============================================================================
// Features calendar ticket blocks, relative countdown badges, interactive
// search, filter pills, share links, and celebratory confetti registration.
// ============================================================================

let allEvents = [];
let allMembersCache = [];
let activeTimeFilter = 'all'; // 'all', 'upcoming', 'past'

async function loadEvents() {
  const container = document.getElementById('eventsGrid');
  if (!container) return;

  container.innerHTML = '<div class="spinner"></div>';

  try {
    const res = await fetch('/api/events');
    const result = await res.json();

    if (!result.success) {
      throw new Error(result.message || 'Failed to load events');
    }

    allEvents = result.data;
    populateClubFilter(allEvents);
    filterAndRenderEvents();
  } catch (err) {
    console.error('Error loading events:', err);
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">⚠️</div>
        <div class="empty-title">Error Loading Events</div>
        <p>${escapeHTML(err.message)}</p>
        <button class="btn btn-secondary btn-sm" onclick="loadEvents()" style="margin-top: 1rem;">Retry</button>
      </div>
    `;
  }
}

function populateClubFilter(events) {
  const select = document.getElementById('eventClubFilter');
  if (!select) return;

  const currentVal = select.value;
  const clubs = Array.from(new Set(events.map(e => e.club_name).filter(Boolean))).sort();

  select.innerHTML = '<option value="">All Clubs</option>';
  clubs.forEach(clubName => {
    const opt = document.createElement('option');
    opt.value = clubName;
    opt.textContent = clubName;
    if (clubName === currentVal) opt.selected = true;
    select.appendChild(opt);
  });
}

function selectTimeFilter(filter) {
  activeTimeFilter = filter;
  document.querySelectorAll('.filter-pill[data-time]').forEach(p => {
    p.classList.toggle('active', p.getAttribute('data-time') === filter);
  });
  filterAndRenderEvents();
}

function renderEvents(events) {
  const container = document.getElementById('eventsGrid');
  const countBadge = document.getElementById('eventResultsCount');
  if (!container) return;

  if (countBadge) {
    countBadge.textContent = `Showing ${events.length} of ${allEvents.length} events`;
  }

  if (events.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">🎉</div>
        <div class="empty-title">No Events Found</div>
        <p>No events match your current filter. Try selecting "All Events".</p>
        <button class="btn btn-secondary btn-sm" onclick="resetEventFilters()" style="margin-top: 1rem;">Reset Filters</button>
      </div>
    `;
    return;
  }

  container.innerHTML = events.map(ev => {
    const dateParts = getEventDateParts(ev.event_date);
    const countdown = getEventCountdownPill(ev.event_date);

    return `
      <div class="card event-card">
        <div class="card-header" style="padding-bottom: 0.65rem;">
          <div class="event-ticket-top">
            <div class="calendar-box">
              <div class="calendar-month">${dateParts.month}</div>
              <div class="calendar-day">${dateParts.day}</div>
            </div>
            <div>
              <h3 class="card-title">${escapeHTML(ev.title)}</h3>
              <div style="margin-top: 0.35rem; display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap;">
                ${countdown}
                <span class="badge badge-tech" style="font-size: 0.75rem;">🏛️ ${escapeHTML(ev.club_name)}</span>
              </div>
            </div>
          </div>
        </div>

        <div class="card-body">
          <p class="card-desc">${escapeHTML(ev.description || 'No description provided for this event.')}</p>
          <div class="card-meta">
            <div class="meta-item">
              <span>📅 Date & Time:</span>
              <strong>${formatDateTime(ev.event_date)}</strong>
            </div>
            <div class="meta-item">
              <span>📍 Venue:</span>
              <strong>${escapeHTML(ev.venue || 'Campus Auditorium')}</strong>
            </div>
            <div class="meta-item" style="justify-content: space-between; margin-top: 0.25rem;">
              <span>🎟️ Attendees:</span>
              <strong style="color: var(--primary);">${ev.registered_count || 0} registered</strong>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <button class="btn btn-primary btn-sm" onclick="openRegisterModal(${ev.event_id}, '${escapeHTML(ev.title)}', '${formatDateTime(ev.event_date)}')">
            🎟️ Register Now
          </button>
          <div style="display: flex; gap: 0.4rem;">
            <button onclick="shareEvent(${ev.event_id}, '${escapeHTML(ev.title)}')" class="btn btn-secondary btn-sm" title="Share event">🔗</button>
            <a href="club-details.html?id=${ev.club_id}" class="btn btn-secondary btn-sm">Club Details</a>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function filterAndRenderEvents() {
  const searchInput = document.getElementById('eventSearchInput');
  const clubFilter = document.getElementById('eventClubFilter');
  const sortSelect = document.getElementById('eventSortSelect');
  const clearBtn = document.getElementById('eventSearchClear');

  const term = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const selectedClub = clubFilter ? clubFilter.value : '';
  const sortMode = sortSelect ? sortSelect.value : 'date-asc';

  if (clearBtn) {
    clearBtn.style.display = term ? 'block' : 'none';
  }

  const now = new Date().getTime();

  let filtered = allEvents.filter(ev => {
    const matchesSearch = 
      (ev.title && ev.title.toLowerCase().includes(term)) ||
      (ev.description && ev.description.toLowerCase().includes(term)) ||
      (ev.venue && ev.venue.toLowerCase().includes(term)) ||
      (ev.club_name && ev.club_name.toLowerCase().includes(term));

    const matchesClub = !selectedClub || ev.club_name === selectedClub;

    // Time filter
    let matchesTime = true;
    if (activeTimeFilter !== 'all' && ev.event_date) {
      const eventTime = new Date(ev.event_date).getTime();
      if (activeTimeFilter === 'upcoming') matchesTime = eventTime >= (now - 86400000); // within last 24h or future
      if (activeTimeFilter === 'past') matchesTime = eventTime < (now - 86400000);
    }

    return matchesSearch && matchesClub && matchesTime;
  });

  // Sorting
  filtered.sort((a, b) => {
    const dateA = new Date(a.event_date || 0).getTime();
    const dateB = new Date(b.event_date || 0).getTime();
    if (sortMode === 'date-asc') return dateA - dateB;
    if (sortMode === 'date-desc') return dateB - dateA;
    if (sortMode === 'title-asc') return (a.title || '').localeCompare(b.title || '');
    if (sortMode === 'regs-desc') return (b.registered_count || 0) - (a.registered_count || 0);
    return 0;
  });

  renderEvents(filtered);
}

function resetEventFilters() {
  const searchInput = document.getElementById('eventSearchInput');
  if (searchInput) searchInput.value = '';
  const clubFilter = document.getElementById('eventClubFilter');
  if (clubFilter) clubFilter.value = '';
  selectTimeFilter('all');
}

function shareEvent(id, title) {
  const url = `${window.location.origin}/events.html?event_id=${id}`;
  copyToClipboard(url, `Link to "${title}" copied to clipboard!`);
}

// ----------------------------------------------------------------------------
// Event Registration Modal Logic
// ----------------------------------------------------------------------------
async function openRegisterModal(eventId, eventTitle, eventDate) {
  document.getElementById('modalEventTitle').textContent = eventTitle;
  document.getElementById('modalEventDate').textContent = eventDate;
  document.getElementById('regEventId').value = eventId;

  const memberSelect = document.getElementById('regMemberSelect');
  memberSelect.innerHTML = '<option value="">-- Loading Members... --</option>';

  const modal = document.getElementById('registerModal');
  modal.classList.add('active');

  try {
    if (allMembersCache.length === 0) {
      const res = await fetch('/api/members');
      const data = await res.json();
      allMembersCache = data.data || [];
    }

    if (allMembersCache.length === 0) {
      memberSelect.innerHTML = '<option value="">No members registered yet. Please add a member first.</option>';
      return;
    }

    memberSelect.innerHTML = '<option value="">-- Select Member / Student --</option>' + 
      allMembersCache.map(m => `
        <option value="${m.member_id}">
          ${escapeHTML(m.full_name)} (${escapeHTML(m.usn)} - ${escapeHTML(m.course)})
        </option>
      `).join('');
  } catch (err) {
    console.error('Error loading members for registration:', err);
    memberSelect.innerHTML = '<option value="">Failed to load members</option>';
  }
}

function closeRegisterModal() {
  const modal = document.getElementById('registerModal');
  if (modal) modal.classList.remove('active');
  const form = document.getElementById('modalRegisterForm');
  if (form) form.reset();
}

async function submitEventRegistration(e) {
  e.preventDefault();

  const eventId = document.getElementById('regEventId').value;
  const memberId = document.getElementById('regMemberSelect').value;

  if (!eventId || !memberId) {
    showAlert('Please select a student member to register.', 'danger');
    return;
  }

  const submitBtn = document.getElementById('btnSubmitRegistration');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.textContent = 'Registering...';
  }

  try {
    const res = await fetch('/api/registrations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event_id: eventId,
        member_id: memberId,
        registered_on: new Date().toISOString()
      })
    });

    const result = await res.json();

    if (!result.success) throw new Error(result.message || 'Registration failed');

    // CELEBRATORY CONFETTI BURST! 🎊
    fireConfetti();
    showAlert('🎉 ' + (result.message || 'Registration successful!'), 'success');
    closeRegisterModal();
    loadEvents();
  } catch (err) {
    showAlert(err.message, 'danger');
  } finally {
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Confirm Registration';
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadEvents();

  const searchInput = document.getElementById('eventSearchInput');
  if (searchInput) searchInput.addEventListener('input', filterAndRenderEvents);

  const clubFilter = document.getElementById('eventClubFilter');
  if (clubFilter) clubFilter.addEventListener('change', filterAndRenderEvents);

  const sortSelect = document.getElementById('eventSortSelect');
  if (sortSelect) sortSelect.addEventListener('change', filterAndRenderEvents);

  const clearBtn = document.getElementById('eventSearchClear');
  if (clearBtn) clearBtn.addEventListener('click', () => {
    if (searchInput) {
      searchInput.value = '';
      filterAndRenderEvents();
    }
  });

  const regForm = document.getElementById('modalRegisterForm');
  if (regForm) regForm.addEventListener('submit', submitEventRegistration);

  const modal = document.getElementById('registerModal');
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeRegisterModal();
    });
  }
});
