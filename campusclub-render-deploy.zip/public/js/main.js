// ============================================================================
// main.js - Ultra-Interactive UI Utilities & Animations
// ============================================================================
// Powers dynamic interactions: animated number counters, button click ripples,
// celebratory confetti bursts, event calendar blocks, and copy-to-clipboard.
// ============================================================================

// Intercept all fetch() calls to bypass tunnel reminders and handle cloud proxies
(function() {
  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    let [resource, config] = args;
    config = config || {};
    config.headers = config.headers || {};
    if (typeof Headers !== 'undefined' && config.headers instanceof Headers) {
      if (!config.headers.has('Bypass-Tunnel-Reminder')) {
        config.headers.set('Bypass-Tunnel-Reminder', 'true');
      }
    } else {
      config.headers['Bypass-Tunnel-Reminder'] = 'true';
    }
    return originalFetch(resource, config);
  };
})();

// ----------------------------------------------------------------------------
// 1. Toast Notification System with Animation & Progress
// ----------------------------------------------------------------------------
function showAlert(message, type = 'success') {
  let container = document.querySelector('.alert-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'alert-container';
    document.body.appendChild(container);
  }

  const alert = document.createElement('div');
  alert.className = `alert alert-${type}`;

  const icon = type === 'success' ? '✨' : type === 'danger' ? '⚠️' : 'ℹ️';

  alert.innerHTML = `
    <div style="display: flex; align-items: center; gap: 0.65rem;">
      <span style="font-size: 1.25rem;">${icon}</span>
      <span>${escapeHTML(message)}</span>
    </div>
    <button style="background:none; border:none; cursor:pointer; font-size: 1.25rem; color:inherit; opacity: 0.7;" onclick="this.parentElement.remove()">&times;</button>
  `;

  container.appendChild(alert);

  setTimeout(() => {
    alert.style.transition = 'all 0.4s ease';
    alert.style.opacity = '0';
    alert.style.transform = 'translateX(100%)';
    setTimeout(() => alert.remove(), 400);
  }, 4500);
}

// ----------------------------------------------------------------------------
// 2. Animated Number Counter (e.g. 0 -> 24)
// ----------------------------------------------------------------------------
function animateCounter(element, target, duration = 1200) {
  if (!element) return;
  const targetNum = parseInt(target, 10);
  if (isNaN(targetNum) || targetNum <= 0) {
    element.textContent = target;
    return;
  }

  let startTimestamp = null;
  const step = (timestamp) => {
    if (!startTimestamp) startTimestamp = timestamp;
    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
    // Ease out cubic
    const currentVal = Math.floor((1 - Math.pow(1 - progress, 3)) * targetNum);
    element.textContent = currentVal;
    if (progress < 1) {
      window.requestAnimationFrame(step);
    } else {
      element.textContent = targetNum;
    }
  };
  window.requestAnimationFrame(step);
}

// ----------------------------------------------------------------------------
// 3. Button Click Ripple Effect
// ----------------------------------------------------------------------------
function initButtonRipples() {
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn');
    if (!btn) return;

    const rect = btn.getBoundingClientRect();
    const ripple = document.createElement('span');
    ripple.className = 'ripple';

    const size = Math.max(rect.width, rect.height);
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${e.clientX - rect.left - size / 2}px`;
    ripple.style.top = `${e.clientY - rect.top - size / 2}px`;

    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
  });
}

// ----------------------------------------------------------------------------
// 4. Celebratory Confetti Burst Animation (Pure JS, Lightweight Canvas)
// ----------------------------------------------------------------------------
function fireConfetti() {
  let canvas = document.getElementById('confettiCanvas');
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.id = 'confettiCanvas';
    document.body.appendChild(canvas);
  }

  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  const particles = [];
  const colors = ['#4f46e5', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

  for (let i = 0; i < 90; i++) {
    particles.push({
      x: canvas.width / 2,
      y: canvas.height * 0.4,
      vx: (Math.random() - 0.5) * 16,
      vy: (Math.random() - 0.8) * 14,
      size: Math.random() * 8 + 4,
      color: colors[Math.floor(Math.random() * colors.length)],
      rotation: Math.random() * 360,
      vRotation: (Math.random() - 0.5) * 12,
      opacity: 1
    });
  }

  let animationFrame;
  function updateConfetti() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let alive = false;

    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.35; // Gravity
      p.vx *= 0.98; // Friction
      p.rotation += p.vRotation;
      p.opacity -= 0.012;

      if (p.opacity > 0) {
        alive = true;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.globalAlpha = p.opacity;
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      }
    });

    if (alive) {
      animationFrame = requestAnimationFrame(updateConfetti);
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  }

  updateConfetti();
}

// ----------------------------------------------------------------------------
// 5. Date & Time Helpers
// ----------------------------------------------------------------------------
function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  } catch (e) {
    return dateStr;
  }
}

function formatDateTime(dateTimeStr) {
  if (!dateTimeStr) return 'N/A';
  try {
    const d = new Date(dateTimeStr);
    if (isNaN(d.getTime())) return dateTimeStr;
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch (e) {
    return dateTimeStr;
  }
}

// Returns Month (e.g. "NOV") and Day (e.g. "15") for ticket badge
function getEventDateParts(dateTimeStr) {
  if (!dateTimeStr) return { month: 'TBD', day: '--' };
  try {
    const d = new Date(dateTimeStr);
    if (isNaN(d.getTime())) return { month: 'DATE', day: '?' };
    const month = d.toLocaleDateString('en-US', { month: 'short' }).toUpperCase();
    const day = d.getDate();
    return { month, day };
  } catch (e) {
    return { month: 'DATE', day: '?' };
  }
}

// Returns relative countdown label: "In 2 days", "Today!", "Past Event"
function getEventCountdownPill(dateTimeStr) {
  if (!dateTimeStr) return '';
  const eventTime = new Date(dateTimeStr).getTime();
  if (isNaN(eventTime)) return '';

  const now = new Date().getTime();
  const diffDays = Math.round((eventTime - now) / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return `<span class="countdown-pill" style="background:#f1f5f9; color:#64748b;">🏁 Past Event</span>`;
  } else if (diffDays === 0) {
    return `<span class="countdown-pill countdown-today">🔥 Today!</span>`;
  } else if (diffDays === 1) {
    return `<span class="countdown-pill countdown-soon">⚡ Tomorrow</span>`;
  } else if (diffDays <= 7) {
    return `<span class="countdown-pill countdown-soon">⏳ In ${diffDays} days</span>`;
  } else {
    return `<span class="countdown-pill countdown-future">📅 In ${diffDays} days</span>`;
  }
}

// ----------------------------------------------------------------------------
// 6. Avatar Initial Circles
// ----------------------------------------------------------------------------
function getAvatarHTML(name) {
  if (!name) return `<div class="avatar">👤</div>`;
  const clean = name.trim();
  const parts = clean.split(' ');
  const initials = parts.length > 1
    ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
    : clean.slice(0, 2).toUpperCase();

  // Pick deterministic vibrant gradient
  const gradients = [
    'linear-gradient(135deg, #4f46e5, #7c3aed)',
    'linear-gradient(135deg, #0ea5e9, #0284c7)',
    'linear-gradient(135deg, #10b981, #059669)',
    'linear-gradient(135deg, #f59e0b, #d97706)',
    'linear-gradient(135deg, #ec4899, #be185d)',
    'linear-gradient(135deg, #8b5cf6, #6d28d9)'
  ];
  let sum = 0;
  for (let i = 0; i < clean.length; i++) sum += clean.charCodeAt(i);
  const grad = gradients[sum % gradients.length];

  return `<div class="avatar" style="background: ${grad}">${initials}</div>`;
}

// ----------------------------------------------------------------------------
// 7. Category Badges
// ----------------------------------------------------------------------------
function getCategoryBadge(category) {
  if (!category) return '<span class="badge badge-other">General</span>';
  const catLower = category.toLowerCase();
  let badgeClass = 'badge-other';
  let icon = '🏷️';

  if (catLower.includes('tech') || catLower.includes('code') || catLower.includes('robot')) {
    badgeClass = 'badge-tech';
    icon = '💻';
  } else if (catLower.includes('cultur') || catLower.includes('music') || catLower.includes('dance') || catLower.includes('art')) {
    badgeClass = 'badge-cultural';
    icon = '🎭';
  } else if (catLower.includes('sport') || catLower.includes('fit') || catLower.includes('game')) {
    badgeClass = 'badge-sports';
    icon = '⚽';
  } else if (catLower.includes('liter') || catLower.includes('debate') || catLower.includes('book')) {
    badgeClass = 'badge-literary';
    icon = '📚';
  } else if (catLower.includes('social') || catLower.includes('service') || catLower.includes('nss')) {
    badgeClass = 'badge-social';
    icon = '🤝';
  } else if (catLower.includes('entrepreneur') || catLower.includes('startup')) {
    badgeClass = 'badge-literary';
    icon = '🚀';
  }

  return `<span class="badge ${badgeClass}">${icon} ${escapeHTML(category)}</span>`;
}

// ----------------------------------------------------------------------------
// 7.5 Club Logo Generator & Description Cleaner
// ----------------------------------------------------------------------------
function getClubLogoHTML(club, size = 'md') {
  if (!club) return `<div class="club-logo-badge club-logo-${size}">🏛️</div>`;

  const name = (club.club_name || '').toLowerCase();
  const cat = (club.category || '').toLowerCase();
  const desc = (club.description || '');

  // 1. Check if description has an explicit icon like [icon:🤖] or [icon:💻]
  let icon = null;
  const match = desc.match(/\[icon:([^\]]+)\]/);
  if (match && match[1]) {
    icon = match[1];
  }

  // 2. Map default icon and gradient if not explicitly provided
  let gradient = 'linear-gradient(135deg, #4f46e5, #7c3aed)';

  if (!icon) {
    if (name.includes('code') || name.includes('developer') || name.includes('web') || name.includes('hack') || name.includes('acm') || name.includes('gdsc') || cat.includes('tech')) {
      icon = '💻';
      gradient = 'linear-gradient(135deg, #3b82f6, #1d4ed8)';
    } else if (name.includes('robot') || name.includes('ai') || name.includes('drone') || name.includes('auto')) {
      icon = '🤖';
      gradient = 'linear-gradient(135deg, #06b6d4, #0e7490)';
    } else if (name.includes('music') || name.includes('crescendo') || name.includes('band') || name.includes('sound')) {
      icon = '🎵';
      gradient = 'linear-gradient(135deg, #ec4899, #be185d)';
    } else if (name.includes('photo') || name.includes('shutter') || name.includes('film') || name.includes('media')) {
      icon = '📸';
      gradient = 'linear-gradient(135deg, #f59e0b, #b45309)';
    } else if (name.includes('entrepreneur') || name.includes('startup') || name.includes('e-cell') || cat.includes('entrepreneur')) {
      icon = '🚀';
      gradient = 'linear-gradient(135deg, #6366f1, #4338ca)';
    } else if (name.includes('literary') || name.includes('debate') || name.includes('mun') || cat.includes('literary')) {
      icon = '📚';
      gradient = 'linear-gradient(135deg, #8b5cf6, #6d28d9)';
    } else if (name.includes('sport') || name.includes('blitz') || name.includes('athletic') || cat.includes('sport')) {
      icon = '⚽';
      gradient = 'linear-gradient(135deg, #10b981, #047857)';
    } else if (name.includes('social') || name.includes('rotaract') || name.includes('nss') || cat.includes('social')) {
      icon = '🤝';
      gradient = 'linear-gradient(135deg, #f97316, #c2410c)';
    } else if (cat.includes('cultur') || name.includes('dance') || name.includes('drama')) {
      icon = '🎭';
      gradient = 'linear-gradient(135deg, #a855f7, #7e22ce)';
    } else {
      icon = '🏛️';
      gradient = 'linear-gradient(135deg, #64748b, #334155)';
    }
  } else {
    if (icon === '💻') gradient = 'linear-gradient(135deg, #3b82f6, #1d4ed8)';
    else if (icon === '🤖') gradient = 'linear-gradient(135deg, #06b6d4, #0e7490)';
    else if (icon === '🎵') gradient = 'linear-gradient(135deg, #ec4899, #be185d)';
    else if (icon === '📸') gradient = 'linear-gradient(135deg, #f59e0b, #b45309)';
    else if (icon === '🚀') gradient = 'linear-gradient(135deg, #6366f1, #4338ca)';
    else if (icon === '📚') gradient = 'linear-gradient(135deg, #8b5cf6, #6d28d9)';
    else if (icon === '⚽') gradient = 'linear-gradient(135deg, #10b981, #047857)';
    else if (icon === '🤝') gradient = 'linear-gradient(135deg, #f97316, #c2410c)';
    else if (icon === '🎨') gradient = 'linear-gradient(135deg, #a855f7, #7e22ce)';
    else if (icon === '♟️') gradient = 'linear-gradient(135deg, #64748b, #334155)';
  }

  return `
    <div class="club-logo-badge club-logo-${size}" style="background: ${gradient};">
      <span>${icon}</span>
    </div>
  `;
}

function cleanClubDescription(desc) {
  if (!desc) return '';
  return desc.replace(/\[icon:[^\]]+\]\s*/g, '').trim();
}

// ----------------------------------------------------------------------------
// 8. Copy to Clipboard Utility
// ----------------------------------------------------------------------------
function copyToClipboard(text, successMsg = 'Copied to clipboard!') {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      showAlert(successMsg, 'info');
    });
  } else {
    const input = document.createElement('input');
    input.value = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    input.remove();
    showAlert(successMsg, 'info');
  }
}

// ----------------------------------------------------------------------------
// 9. XSS Escaper
// ----------------------------------------------------------------------------
function escapeHTML(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ----------------------------------------------------------------------------
// 10. Initialization
// ----------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  initButtonRipples();

  // Mobile menu toggle
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', () => {
      navLinks.classList.toggle('show');
    });
  }

  // Active navigation link indicator
  const currentPath = window.location.pathname;
  const links = document.querySelectorAll('.nav-link');
  links.forEach(link => {
    const href = link.getAttribute('href');
    if (href && (currentPath.endsWith(href) || (currentPath === '/' && href === 'index.html'))) {
      link.classList.add('active');
    }
  });
});
