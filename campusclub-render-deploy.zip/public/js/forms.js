// ============================================================================
// forms.js - Interactive Form Handlers with Real-Time Card Previews
// ============================================================================
// Manages validation, dynamic dropdown population, real-time live preview cards,
// character counters, and celebratory submission feedback.
// ============================================================================

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('addClubForm')) initAddClubForm();
  if (document.getElementById('editClubForm')) initEditClubForm();
  if (document.getElementById('addMemberForm')) initAddMemberForm();
  if (document.getElementById('addEventForm')) initAddEventForm();
  if (document.getElementById('joinClubForm')) initJoinClubForm();
});

// ----------------------------------------------------------------------------
// 1. ADD CLUB FORM with Live Preview & Character Counter
// ----------------------------------------------------------------------------
function initAddClubForm() {
  const form = document.getElementById('addClubForm');
  const foundedInput = document.getElementById('clubFounded');
  if (foundedInput && !foundedInput.value) {
    foundedInput.value = new Date().getFullYear();
  }

  // Real-time Live Preview
  const nameInput = document.getElementById('clubName');
  const catInput = document.getElementById('clubCategory');
  const coordInput = document.getElementById('clubCoordinator');
  const descInput = document.getElementById('clubDesc');
  const previewCard = document.getElementById('liveClubPreview');
  const charCounter = document.getElementById('descCharCount');
  const logoInput = document.getElementById('selectedLogoIcon');

  // Logo picker buttons
  const logoBtns = document.querySelectorAll('.logo-option-btn');
  logoBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      logoBtns.forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      if (logoInput) logoInput.value = btn.getAttribute('data-icon');
      updatePreview();
    });
  });

  function updatePreview() {
    if (!previewCard) return;
    const name = nameInput.value.trim() || 'Club Name Preview';
    const cat = catInput.value || 'Technical';
    const coord = coordInput.value.trim() || 'Faculty Coordinator Name';
    const year = (foundedInput && foundedInput.value) ? foundedInput.value : new Date().getFullYear();
    const desc = descInput.value.trim() || 'Your club description will appear right here as you type...';
    const icon = logoInput ? logoInput.value : '💻';

    const dummyClub = {
      club_name: name,
      category: cat,
      description: `[icon:${icon}] ${desc}`
    };

    previewCard.innerHTML = `
      <div class="card">
        <div class="card-header">
          <div class="club-title-row">
            ${getClubLogoHTML(dummyClub, 'md')}
            <div>
              <h3 class="card-title">${escapeHTML(name)}</h3>
              <div style="margin-top: 0.35rem;">${getCategoryBadge(cat)}</div>
            </div>
          </div>
        </div>
        <div class="card-body">
          <p class="card-desc">${escapeHTML(desc)}</p>
          <div class="card-meta">
            <div class="meta-item"><span>👤 Coordinator:</span> <strong>${escapeHTML(coord)}</strong></div>
            <div class="meta-item"><span>📅 Established:</span> <strong>${escapeHTML(year)}</strong></div>
            <div class="meta-item" style="justify-content: space-between; margin-top: 0.25rem;">
              <span class="badge badge-tech">👥 0 Members</span>
              <span class="badge badge-sports">🎉 0 Events</span>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <span class="btn btn-primary btn-sm" style="pointer-events: none; opacity: 0.7;">Explore Club</span>
        </div>
      </div>
    `;

    if (charCounter) {
      charCounter.textContent = `${descInput.value.length} characters`;
    }
  }

  if (nameInput) nameInput.addEventListener('input', updatePreview);
  if (catInput) catInput.addEventListener('change', updatePreview);
  if (coordInput) coordInput.addEventListener('input', updatePreview);
  if (foundedInput) foundedInput.addEventListener('input', updatePreview);
  if (descInput) descInput.addEventListener('input', updatePreview);
  updatePreview();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating Club...';

    const selectedIcon = logoInput ? logoInput.value : '💻';
    const payload = {
      club_name: nameInput.value.trim(),
      category: catInput.value,
      faculty_coordinator: coordInput.value.trim(),
      founded_year: foundedInput.value,
      description: `[icon:${selectedIcon}] ${descInput.value.trim()}`
    };

    try {
      const res = await fetch('/api/clubs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (!data.success) throw new Error(data.message || 'Failed to create club');

      fireConfetti();
      showAlert('🎉 ' + (data.message || 'Club created successfully!'), 'success');
      form.reset();

      setTimeout(() => {
        window.location.href = 'clubs.html';
      }, 1100);
    } catch (err) {
      console.error('Error adding club:', err);
      showAlert(err.message, 'danger');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  });
}

// ----------------------------------------------------------------------------
// 2. EDIT CLUB FORM
// ----------------------------------------------------------------------------
async function initEditClubForm() {
  const form = document.getElementById('editClubForm');
  const urlParams = new URLSearchParams(window.location.search);
  const clubId = urlParams.get('id');

  if (!clubId) {
    showAlert('No club ID specified for editing.', 'danger');
    return;
  }

  try {
    const res = await fetch(`/api/clubs/${clubId}`);
    const data = await res.json();

    if (!data.success || !data.data) throw new Error(data.message || 'Club not found');

    const club = data.data;
    let existingIcon = '';
    const match = (club.description || '').match(/\[icon:([^\]]+)\]/);
    if (match) existingIcon = match[1];

    document.getElementById('editClubId').value = club.club_id;
    document.getElementById('editClubName').value = club.club_name || '';
    document.getElementById('editClubCategory').value = club.category || 'Technical';
    document.getElementById('editClubCoordinator').value = club.faculty_coordinator || '';
    document.getElementById('editClubFounded').value = club.founded_year || '';
    document.getElementById('editClubDesc').value = cleanClubDescription(club.description) || '';
  } catch (err) {
    showAlert('Error loading club data: ' + err.message, 'danger');
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Saving Changes...';

    const match = (document.getElementById('editClubDesc').value || '').match(/\[icon:([^\]]+)\]/);
    const iconPrefix = match ? '' : (existingIcon ? `[icon:${existingIcon}] ` : '');

    const payload = {
      club_name: document.getElementById('editClubName').value.trim(),
      category: document.getElementById('editClubCategory').value,
      faculty_coordinator: document.getElementById('editClubCoordinator').value.trim(),
      founded_year: document.getElementById('editClubFounded').value,
      description: `${iconPrefix}${document.getElementById('editClubDesc').value.trim()}`
    };

    try {
      const res = await fetch(`/api/clubs/${clubId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (!data.success) throw new Error(data.message || 'Failed to update club');

      showAlert('✨ Club updated successfully!', 'success');
      setTimeout(() => {
        window.location.href = `club-details.html?id=${clubId}`;
      }, 900);
    } catch (err) {
      console.error('Error updating club:', err);
      showAlert(err.message, 'danger');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  });
}

// ----------------------------------------------------------------------------
// 3. ADD MEMBER FORM
// ----------------------------------------------------------------------------
function initAddMemberForm() {
  const form = document.getElementById('addMemberForm');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Registering Student...';

    const payload = {
      full_name: document.getElementById('memberName').value.trim(),
      usn: document.getElementById('memberUsn').value.trim().toUpperCase(),
      email: document.getElementById('memberEmail').value.trim().toLowerCase(),
      phone: document.getElementById('memberPhone').value.trim(),
      course: document.getElementById('memberCourse').value.trim(),
      semester: document.getElementById('memberSemester').value
    };

    try {
      const res = await fetch('/api/members', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (!data.success) throw new Error(data.message || 'Failed to add member');

      fireConfetti();
      showAlert('🎓 ' + (data.message || 'Student enrolled successfully!'), 'success');
      form.reset();

      setTimeout(() => {
        window.location.href = 'members.html';
      }, 1100);
    } catch (err) {
      console.error('Error registering member:', err);
      showAlert(err.message, 'danger');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  });
}

// ----------------------------------------------------------------------------
// 4. ADD EVENT FORM with Live Preview
// ----------------------------------------------------------------------------
async function initAddEventForm() {
  const form = document.getElementById('addEventForm');
  const clubSelect = document.getElementById('eventClubSelect');
  const titleInput = document.getElementById('eventTitle');
  const dateInput = document.getElementById('eventDateTime');
  const venueInput = document.getElementById('eventVenue');
  const descInput = document.getElementById('eventDesc');
  const previewContainer = document.getElementById('liveEventPreview');

  const urlParams = new URLSearchParams(window.location.search);
  const preselectedClubId = urlParams.get('club_id');

  try {
    const res = await fetch('/api/clubs');
    const data = await res.json();
    const clubs = data.data || [];

    if (clubs.length === 0) {
      clubSelect.innerHTML = '<option value="">No clubs available. Please add a club first.</option>';
    } else {
      clubSelect.innerHTML = '<option value="">-- Select Organizing Club --</option>' +
        clubs.map(c => `
          <option value="${c.club_id}" ${preselectedClubId && String(preselectedClubId) === String(c.club_id) ? 'selected' : ''}>
            ${escapeHTML(c.club_name)} (${escapeHTML(c.category)})
          </option>
        `).join('');
    }
  } catch (err) {
    console.error('Error loading clubs:', err);
    clubSelect.innerHTML = '<option value="">Failed to load clubs</option>';
  }

  // Pre-set event date to tomorrow at 10:00 AM
  if (dateInput && !dateInput.value) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(10, 0, 0, 0);
    const pad = n => String(n).padStart(2, '0');
    dateInput.value = `${tomorrow.getFullYear()}-${pad(tomorrow.getMonth() + 1)}-${pad(tomorrow.getDate())}T${pad(tomorrow.getHours())}:${pad(tomorrow.getMinutes())}`;
  }

  function updateEventPreview() {
    if (!previewContainer) return;
    const title = (titleInput && titleInput.value.trim()) || 'Event Title Preview';
    const dateVal = (dateInput && dateInput.value) || '';
    const dateParts = getEventDateParts(dateVal);
    const venue = (venueInput && venueInput.value.trim()) || 'Auditorium / Campus Venue';
    const desc = (descInput && descInput.value.trim()) || 'Event agenda, schedule, and attendee information...';
    const selectedClubText = clubSelect.options[clubSelect.selectedIndex]?.text || 'Organizing Club';

    previewContainer.innerHTML = `
      <div class="card event-card">
        <div class="card-header">
          <div class="event-ticket-top">
            <div class="calendar-box">
              <div class="calendar-month">${dateParts.month}</div>
              <div class="calendar-day">${dateParts.day}</div>
            </div>
            <div>
              <h4 class="card-title">${escapeHTML(title)}</h4>
              <div style="font-size: 0.8rem; font-weight: 700; color: var(--primary); margin-top: 0.25rem;">
                🏛️ ${escapeHTML(selectedClubText)}
              </div>
            </div>
          </div>
        </div>
        <div class="card-body">
          <p class="card-desc">${escapeHTML(desc)}</p>
          <div class="card-meta">
            <div class="meta-item"><span>📍 Venue:</span> <strong>${escapeHTML(venue)}</strong></div>
            <div class="meta-item"><span>🕒 Time:</span> <strong>${formatDateTime(dateVal)}</strong></div>
          </div>
        </div>
        <div class="card-footer">
          <span class="btn btn-primary btn-sm" style="pointer-events: none; opacity: 0.7;">🎟️ Register</span>
        </div>
      </div>
    `;
  }

  if (titleInput) titleInput.addEventListener('input', updateEventPreview);
  if (dateInput) dateInput.addEventListener('input', updateEventPreview);
  if (venueInput) venueInput.addEventListener('input', updateEventPreview);
  if (descInput) descInput.addEventListener('input', updateEventPreview);
  if (clubSelect) clubSelect.addEventListener('change', updateEventPreview);
  updateEventPreview();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Publishing Event...';

    const payload = {
      club_id: clubSelect.value,
      title: titleInput.value.trim(),
      event_date: dateInput.value,
      venue: venueInput.value.trim(),
      description: descInput.value.trim()
    };

    try {
      const res = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (!data.success) throw new Error(data.message || 'Failed to create event');

      fireConfetti();
      showAlert('🎉 ' + (data.message || 'Event scheduled successfully!'), 'success');
      form.reset();

      setTimeout(() => {
        window.location.href = 'events.html';
      }, 1100);
    } catch (err) {
      console.error('Error adding event:', err);
      showAlert(err.message, 'danger');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  });
}

// ----------------------------------------------------------------------------
// 5. JOIN CLUB FORM
// ----------------------------------------------------------------------------
async function initJoinClubForm() {
  const form = document.getElementById('joinClubForm');
  const memberSelect = document.getElementById('joinMemberSelect');
  const clubSelect = document.getElementById('joinClubSelect');
  const joinDateInput = document.getElementById('joinDate');

  if (joinDateInput && !joinDateInput.value) {
    joinDateInput.value = new Date().toISOString().slice(0, 10);
  }

  const urlParams = new URLSearchParams(window.location.search);
  const preselectedMemberId = urlParams.get('member_id');
  const preselectedClubId = urlParams.get('club_id');

  try {
    const [membersRes, clubsRes] = await Promise.all([
      fetch('/api/members'),
      fetch('/api/clubs')
    ]);

    const [membersData, clubsData] = await Promise.all([
      membersRes.json(),
      clubsRes.json()
    ]);

    const members = membersData.data || [];
    const clubs = clubsData.data || [];

    if (members.length === 0) {
      memberSelect.innerHTML = '<option value="">No members found. Please register a student first.</option>';
    } else {
      memberSelect.innerHTML = '<option value="">-- Select Student / Member --</option>' +
        members.map(m => `
          <option value="${m.member_id}" ${preselectedMemberId && String(preselectedMemberId) === String(m.member_id) ? 'selected' : ''}>
            ${escapeHTML(m.full_name)} (${escapeHTML(m.usn)} - ${escapeHTML(m.course)})
          </option>
        `).join('');
    }

    if (clubs.length === 0) {
      clubSelect.innerHTML = '<option value="">No clubs found. Please create a club first.</option>';
    } else {
      clubSelect.innerHTML = '<option value="">-- Select Club to Join --</option>' +
        clubs.map(c => `
          <option value="${c.club_id}" ${preselectedClubId && String(preselectedClubId) === String(c.club_id) ? 'selected' : ''}>
            ${escapeHTML(c.club_name)} (${escapeHTML(c.category)})
          </option>
        `).join('');
    }
  } catch (err) {
    console.error('Error loading options:', err);
    showAlert('Error loading members or clubs list: ' + err.message, 'danger');
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Enrolling Member...';

    const payload = {
      member_id: memberSelect.value,
      club_id: clubSelect.value,
      role: document.getElementById('joinRole').value,
      joined_on: joinDateInput.value
    };

    try {
      const res = await fetch('/api/memberships', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (!data.success) throw new Error(data.message || 'Failed to join club');

      fireConfetti();
      showAlert('🤝 ' + (data.message || 'Member joined club successfully!'), 'success');
      form.reset();

      setTimeout(() => {
        window.location.href = `club-details.html?id=${payload.club_id}`;
      }, 1100);
    } catch (err) {
      console.error('Error joining club:', err);
      showAlert(err.message, 'danger');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  });
}
