// ============================================================================
// clubs.js - Interactive Clubs Directory & Management
// ============================================================================
// Supports real-time search, category pill filtering, sorting, shareable links,
// member/event counts, and safe deletion.
// ============================================================================

let allClubs = [];
let activeCategory = '';

async function loadClubs() {
  const container = document.getElementById('clubsGrid');
  if (!container) return;

  container.innerHTML = '<div class="spinner"></div>';

  try {
    const res = await fetch('/api/clubs');
    const result = await res.json();

    if (!result.success) {
      throw new Error(result.message || 'Failed to load clubs');
    }

    allClubs = result.data;

    // Check if URL contains query parameter like ?category=... or ?q=...
    const urlParams = new URLSearchParams(window.location.search);
    const categoryParam = urlParams.get('category');
    const queryParam = urlParams.get('q');

    if (queryParam) {
      const searchInput = document.getElementById('searchInput');
      if (searchInput) searchInput.value = queryParam;
    }

    if (categoryParam) {
      activeCategory = categoryParam;
    }

    renderCategoryPills(allClubs);
    filterAndSortClubs();
  } catch (err) {
    console.error('Error loading clubs:', err);
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">⚠️</div>
        <div class="empty-title">Error Loading Clubs</div>
        <p>${escapeHTML(err.message)}</p>
        <button class="btn btn-secondary btn-sm" onclick="loadClubs()" style="margin-top: 1rem;">Retry</button>
      </div>
    `;
  }
}

// Render interactive category filter pills
function renderCategoryPills(clubs) {
  const pillsContainer = document.getElementById('categoryPills');
  if (!pillsContainer) return;

  const categories = ['All', ...Array.from(new Set(clubs.map(c => c.category).filter(Boolean))).sort()];

  pillsContainer.innerHTML = categories.map(cat => {
    const isAll = cat === 'All';
    const isActive = (isAll && !activeCategory) || activeCategory.toLowerCase() === cat.toLowerCase();
    return `
      <button class="filter-pill ${isActive ? 'active' : ''}" onclick="selectCategory('${isAll ? '' : escapeHTML(cat)}')">
        ${escapeHTML(cat)}
      </button>
    `;
  }).join('');
}

function selectCategory(cat) {
  activeCategory = cat;
  renderCategoryPills(allClubs);
  filterAndSortClubs();
}

function renderClubs(clubs) {
  const container = document.getElementById('clubsGrid');
  const countBadge = document.getElementById('resultsCount');
  if (!container) return;

  if (countBadge) {
    countBadge.textContent = `Showing ${clubs.length} of ${allClubs.length} clubs`;
  }

  if (clubs.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">🔍</div>
        <div class="empty-title">No Matching Clubs Found</div>
        <p>Try clearing your search or selecting a different category filter.</p>
        <button class="btn btn-secondary btn-sm" onclick="resetFilters()" style="margin-top: 1rem;">Reset Filters</button>
      </div>
    `;
    return;
  }

  container.innerHTML = clubs.map(club => `
    <div class="card">
      <div class="card-header">
        <div class="club-title-row">
          ${getClubLogoHTML(club, 'md')}
          <div>
            <h3 class="card-title">${escapeHTML(club.club_name)}</h3>
            <div style="margin-top: 0.35rem;">${getCategoryBadge(club.category)}</div>
          </div>
        </div>
      </div>
      <div class="card-body">
        <p class="card-desc">${escapeHTML(cleanClubDescription(club.description) || 'No description provided.')}</p>
        <div class="card-meta">
          <div class="meta-item">
            <span>👤 Coordinator:</span>
            <strong>${escapeHTML(club.faculty_coordinator || 'Not Assigned')}</strong>
          </div>
          <div class="meta-item">
            <span>📅 Established:</span>
            <strong>${escapeHTML(club.founded_year || 'N/A')}</strong>
          </div>
          <div class="meta-item" style="justify-content: space-between; margin-top: 0.35rem;">
            <span class="badge badge-tech">👥 ${club.member_count || 0} Members</span>
            <span class="badge badge-sports">🎉 ${club.event_count || 0} Events</span>
          </div>
        </div>
      </div>
      <div class="card-footer">
        <a href="club-details.html?id=${club.club_id}" class="btn btn-primary btn-sm">Explore Club →</a>
        <div style="display: flex; gap: 0.4rem;">
          <button onclick="shareClub(${club.club_id}, '${escapeHTML(club.club_name)}')" class="btn btn-secondary btn-sm" title="Copy shareable link">🔗</button>
          <a href="edit-club.html?id=${club.club_id}" class="btn btn-secondary btn-sm" title="Edit Club">✏️</a>
          <button onclick="handleDeleteClub(${club.club_id}, '${escapeHTML(club.club_name)}')" class="btn btn-outline-danger btn-sm" title="Delete Club">🗑️</button>
        </div>
      </div>
    </div>
  `).join('');
}

function filterAndSortClubs() {
  const searchInput = document.getElementById('searchInput');
  const sortSelect = document.getElementById('sortSelect');
  const clearBtn = document.getElementById('searchClearBtn');

  const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const sortMode = sortSelect ? sortSelect.value : 'name-asc';

  if (clearBtn) {
    clearBtn.style.display = searchTerm ? 'block' : 'none';
  }

  let filtered = allClubs.filter(club => {
    const matchesSearch = 
      (club.club_name && club.club_name.toLowerCase().includes(searchTerm)) ||
      (club.description && club.description.toLowerCase().includes(searchTerm)) ||
      (club.faculty_coordinator && club.faculty_coordinator.toLowerCase().includes(searchTerm)) ||
      (club.category && club.category.toLowerCase().includes(searchTerm));

    const matchesCategory = !activeCategory || 
      (club.category && club.category.toLowerCase() === activeCategory.toLowerCase());

    return matchesSearch && matchesCategory;
  });

  // Sorting
  filtered.sort((a, b) => {
    if (sortMode === 'name-asc') return (a.club_name || '').localeCompare(b.club_name || '');
    if (sortMode === 'name-desc') return (b.club_name || '').localeCompare(a.club_name || '');
    if (sortMode === 'members-desc') return (b.member_count || 0) - (a.member_count || 0);
    if (sortMode === 'year-desc') return (b.founded_year || 0) - (a.founded_year || 0);
    return 0;
  });

  renderClubs(filtered);
}

function clearSearch() {
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.value = '';
    filterAndSortClubs();
  }
}

function resetFilters() {
  const searchInput = document.getElementById('searchInput');
  if (searchInput) searchInput.value = '';
  activeCategory = '';
  renderCategoryPills(allClubs);
  filterAndSortClubs();
}

function shareClub(id, name) {
  const url = `${window.location.origin}/club-details.html?id=${id}`;
  copyToClipboard(url, `Link to ${name} copied to clipboard!`);
}

async function handleDeleteClub(clubId, clubName) {
  const confirmed = confirm(`Are you sure you want to delete "${clubName}"?\n\nThis will remove the club and its associated memberships and events. This action cannot be undone.`);
  if (!confirmed) return;

  try {
    const res = await fetch(`/api/clubs/${clubId}`, { method: 'DELETE' });
    const result = await res.json();

    if (!result.success) throw new Error(result.message || 'Failed to delete club');

    showAlert(`Club "${clubName}" was deleted successfully.`, 'success');
    loadClubs();
  } catch (err) {
    showAlert('Error deleting club: ' + err.message, 'danger');
  }
}

async function seedSampleData() {
  const confirmed = confirm('Do you want to load 8 official college clubs (GDSC, RoboTech, E-Cell, Crescendo, Blitz Sports, etc.), 12 student members with leadership roles, and campus events into the database?');
  if (!confirmed) return;

  showAlert('🌱 Seeding sample clubs and students...', 'info');

  try {
    const res = await fetch('/api/seed', { method: 'POST' });
    const result = await res.json();
    if (!result.success) throw new Error(result.message);

    fireConfetti();
    showAlert('🎉 Sample clubs, students, and events loaded successfully!', 'success');
    loadClubs();
  } catch (err) {
    showAlert('Error loading sample data: ' + err.message, 'danger');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadClubs();

  const searchInput = document.getElementById('searchInput');
  if (searchInput) searchInput.addEventListener('input', filterAndSortClubs);

  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) sortSelect.addEventListener('change', filterAndSortClubs);

  const clearBtn = document.getElementById('searchClearBtn');
  if (clearBtn) clearBtn.addEventListener('click', clearSearch);
});
